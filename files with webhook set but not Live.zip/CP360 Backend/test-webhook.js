// test-webhook.js - Run this with: node test-webhook.js

const http = require('http');

const testPayload = {
  locationId: "34aDq5td6waKO9PI60IX",
  id: "test-contact-123",
  firstName: "John",
  lastName: "Doe",
  phone: "+15551234567",
  email: "john@example.com",
  address1: "123 Main St",
  city: "Chicago",
  state: "IL",
  postalCode: "60601",
  "contact.jf_lead_source": "Facebook",
  "contact.est_project_type": "Garage Floor",
  "contact.jf_notes": "Test contact from GHL webhook"
};

const data = JSON.stringify(testPayload);

const options = {
  hostname: 'localhost',
  port: 3001,
  path: '/api/webhooks/ghl/contact',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

console.log('🚀 Sending webhook test to http://localhost:3001/api/webhooks/ghl/contact');
console.log('📦 Payload:', testPayload);
console.log('');

const req = http.request(options, (res) => {
  console.log(`📡 Status Code: ${res.statusCode}`);
  
  let responseData = '';
  
  res.on('data', (chunk) => {
    responseData += chunk;
  });
  
  res.on('end', () => {
    console.log('✅ Response:', responseData);
    try {
      const parsed = JSON.parse(responseData);
      console.log('📋 Parsed:', JSON.stringify(parsed, null, 2));
    } catch (e) {
      console.log('⚠️ Could not parse response as JSON');
    }
  });
});

req.on('error', (error) => {
  console.error('❌ Request Error:', error.message);
  console.error('💡 Make sure your server is running on port 3001');
});

req.write(data);
req.end();