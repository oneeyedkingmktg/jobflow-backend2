// LeadContactSection.jsx — updated 2025-12-10
import React from "react";

export default function LeadContactSection() {
  // This component is now intentionally EMPTY since the
  // Email + Preferred Contact box is no longer needed.
  // Returning null prevents an empty white box from rendering.
  return null;
}
