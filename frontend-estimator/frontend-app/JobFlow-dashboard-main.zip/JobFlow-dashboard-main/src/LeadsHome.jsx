// ============================================================================
// File: src/LeadsHome.jsx
// Version: v2.5 – Fix save wiring + preserve hasEstimate through modal
// ============================================================================

import React, { useState, useMemo, useEffect } from "react";
import { apiRequest, LeadsAPI } from "./api";

import LeadModal from "./LeadModal.jsx";
import CalendarView from "./CalendarView.jsx";
import PhoneLookupModal from "./PhoneLookupModal.jsx";
import SettingsMenu from "./SettingsMenu.jsx";

import { useCompany } from "./CompanyContext.jsx";
import { useAuth } from "./AuthContext.jsx";

import LeadHeader from "./leadComponents/LeadHeader.jsx";
import LeadTabs from "./leadComponents/LeadTabs.jsx";
import LeadSearchBar from "./leadComponents/LeadSearchBar.jsx";
import LeadCard from "./leadComponents/LeadCard.jsx";

import { normalizePhone } from "./leadComponents/leadHelpers.js";

// --------------------------------------------------
// Helpers
// --------------------------------------------------
const normalizeDate = (d) => {
  if (!d) return "";
  let str = String(d).trim();
  if (str.includes("T")) str = str.split("T")[0];
  return str;
};

const convertLeadFromBackend = (lead) => ({
  id: lead.id,
  companyId: lead.companyId,
  createdByUserId: lead.createdByUserId,

  name: lead.fullName || lead.name || "",
  firstName: lead.firstName || "",
  lastName: lead.lastName || "",

  phone: lead.phone,
  email: lead.email,
  preferredContact: lead.preferredContact,

  address: lead.address,
  city: lead.city,
  state: lead.state,
  zip: lead.zip,

  buyerType: lead.buyerType,
  companyName: lead.companyName,
  projectType: lead.projectType,

  leadSource: lead.leadSource,
  referralSource: lead.referralSource,

  status: lead.status,
  notSoldReason: lead.notSoldReason,
  notes: lead.notes,
  contractPrice: lead.contractPrice,

  apptDate: normalizeDate(lead.appointmentDate),
  apptTime: lead.appointmentTime || "",
  installDate: normalizeDate(lead.installDate),
  installTentative: lead.installTentative,

  // 🔑 preserve estimate flag
  hasEstimate: lead.hasEstimate === true,
});

// --------------------------------------------------
// Component
// --------------------------------------------------
export default function LeadsHome({ currentUser }) {
  const { currentCompany } = useCompany();
  const { user } = useAuth();

  const [leads, setLeads] = useState([]);
  const [activeTab, setActiveTab] = useState("Leads");
  const [selectedLead, setSelectedLead] = useState(null);
  const [isNewLead, setIsNewLead] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [showPhoneLookup, setShowPhoneLookup] = useState(false);

  // --------------------------------------------------
  // Load leads
  // --------------------------------------------------
  const loadLeads = async () => {
    setLoading(true);
    try {
      const res = await apiRequest("/leads");
      setLeads((res.leads || []).map(convertLeadFromBackend));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLeads();
  }, []);

  // --------------------------------------------------
  // Save handler (FIXED)
  // --------------------------------------------------
  const handleSaveLead = async (formData, closeAfter = false) => {
    if (formData.id) {
      await LeadsAPI.update(formData.id, formData);
    } else {
      const res = await LeadsAPI.create(formData);
      formData.id = res.lead?.id;
    }

    await loadLeads();

    if (closeAfter) {
      setSelectedLead(null);
      setIsNewLead(false);
    }
  };

  // --------------------------------------------------
  // Filtering
  // --------------------------------------------------
  const filteredLeads = useMemo(() => {
    const term = searchTerm.toLowerCase();
    const digits = normalizePhone(searchTerm);

    return leads.filter((lead) => {
      const nameMatch = lead.name?.toLowerCase().includes(term);
      const cityMatch = lead.city?.toLowerCase().includes(term);
      const phoneMatch = normalizePhone(lead.phone || "").includes(digits);
      return nameMatch || cityMatch || phoneMatch;
    });
  }, [leads, searchTerm]);

  return (
    <div className="min-h-screen bg-gray-100">
      <LeadHeader companyName={currentCompany?.name} />

      <LeadTabs
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        counts={{ Leads: leads.length }}
        onAddLead={() => {
          setSelectedLead(null);
          setIsNewLead(true);
          setShowPhoneLookup(true);
        }}
      />

      <LeadSearchBar
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
      />

      <div className="max-w-7xl mx-auto px-4 pb-10">
        {loading ? (
          <div className="py-10 text-center text-gray-600">Loading...</div>
        ) : filteredLeads.length === 0 ? (
          <div className="py-10 text-center text-gray-500">No leads found.</div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredLeads.map((lead) => (
              <LeadCard
                key={lead.id}
                lead={lead}
                onClick={() => {
                  setSelectedLead(lead);
                  setIsNewLead(false);
                }}
              />
            ))}
          </div>
        )}
      </div>

      {(selectedLead || isNewLead) && (
        <LeadModal
          lead={selectedLead}
          isNew={isNewLead}
          currentUser={currentUser}
          onClose={() => {
            setSelectedLead(null);
            setIsNewLead(false);
          }}
          onSave={handleSaveLead}
        />
      )}

      {showPhoneLookup && (
        <PhoneLookupModal
          leads={leads}
          onClose={() => setShowPhoneLookup(false)}
          onCreateNew={(phone) => {
            setSelectedLead({ id: null, name: "", phone, status: "lead" });
            setIsNewLead(true);
            setShowPhoneLookup(false);
          }}
          onSelectExisting={(lead) => {
            setSelectedLead(lead);
            setIsNewLead(false);
            setShowPhoneLookup(false);
          }}
        />
      )}
    </div>
  );
}
