// ============================================================================
// AuthContext – Correctly Maps company_id → companyId
// Version: v3.1 – Localhost dev auth bypass (frontend only)
// ============================================================================

import { createContext, useContext, useState, useEffect } from "react";
import { AuthAPI } from "./api";

const AuthContext = createContext();
export { AuthContext };

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

// Normalize backend user → frontend shape
const normalizeUser = (u) => {
  if (!u) return null;

  return {
    id: u.id,
    email: u.email,
    role: u.role,
    isActive: u.is_active ?? true,

    // Company fields (critical)
    companyId: u.company_id ?? u.companyId ?? null,
    companyName: u.company_name ?? u.companyName ?? null,
    ghlLocationId: u.ghl_location_id ?? null,
  };
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // ------------------------------------------------------------
  // DEV MODE: Localhost auth bypass (FRONTEND ONLY)
  // ------------------------------------------------------------
  useEffect(() => {
    const isLocalhost =
      window.location.hostname === "localhost" ||
      window.location.hostname === "127.0.0.1";

    if (isLocalhost) {
      // Fake authenticated user tied to a real company_id
      // ⚠️ Adjust companyId if needed to match your DB
      const devUser = {
        id: "dev-user",
        email: "dev@local.test",
        role: "admin",
        isActive: true,
        companyId: 1,
        companyName: "Dev Company",
        ghlLocationId: null,
      };

      setUser(devUser);
      setIsAuthenticated(true);
      setIsLoading(false);
      return;
    }

    // ------------------------------------------------------------
    // NORMAL AUTH FLOW (non-localhost)
    // ------------------------------------------------------------
    const token = localStorage.getItem("authToken");
    if (!token) {
      setIsAuthenticated(false);
      setIsLoading(false);
      return;
    }

    const loadUser = async () => {
      try {
        const me = await AuthAPI.me();
        const normalized = normalizeUser(me.user);
        setUser(normalized);
        setIsAuthenticated(true);
      } catch {
        localStorage.removeItem("authToken");
        setUser(null);
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();
  }, []);

  // ------------------------------------------------------------
  // Login (unchanged)
  // ------------------------------------------------------------
  const login = async (email, password) => {
    try {
      setError(null);
      setIsLoading(true);

      const res = await AuthAPI.login(email, password);

      localStorage.setItem("authToken", res.token);

      const normalized = normalizeUser(res.user);
      setUser(normalized);
      setIsAuthenticated(true);

      return { success: true };
    } catch (err) {
      const message = err.message || "Login failed";
      setError(message);
      return { success: false, error: message };
    } finally {
      setIsLoading(false);
    }
  };

  // ------------------------------------------------------------
  // Logout (unchanged)
  // ------------------------------------------------------------
  const logout = () => {
    localStorage.removeItem("authToken");
    setUser(null);
    setIsAuthenticated(false);
  };

  // Helper: is this user the master account?
  const isMaster = () => {
    return user?.role === "master";
  };

  const value = {
    user,
    isAuthenticated,
    isLoading,
    error,
    login,
    logout,
    isMaster,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
