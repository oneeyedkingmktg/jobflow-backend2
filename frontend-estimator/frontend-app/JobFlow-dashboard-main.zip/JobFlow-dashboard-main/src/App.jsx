// ============================================================================
// File: src/App.jsx
// Version: v1.3.1 – Restore Providers + Mount LeadsHome
// ============================================================================

import React from "react";
import "./index.css";

import { AuthProvider } from "./AuthContext";
import { CompanyProvider } from "./CompanyContext";
import LeadsHome from "./LeadsHome.jsx";

/* ===========================================================
   Error Boundary
   =========================================================== */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, message: error.message || "Unknown error" };
  }

  componentDidCatch(error, info) {
    console.error("React ErrorBoundary:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-red-50">
          <div className="p-8 bg-white rounded-xl shadow-xl max-w-lg">
            <h1 className="text-2xl font-bold text-red-600 mb-2">App Error</h1>
            <p className="text-gray-700 mb-4">{this.state.message}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg font-bold"
            >
              Reload App
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

/* ===========================================================
   APP ROOT
   =========================================================== */
export default function App() {
  return (
    <AuthProvider>
      <CompanyProvider>
        <ErrorBoundary>
          <LeadsHome />
        </ErrorBoundary>
      </CompanyProvider>
    </AuthProvider>
  );
}
